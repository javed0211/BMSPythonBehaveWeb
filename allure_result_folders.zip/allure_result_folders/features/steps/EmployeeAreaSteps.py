from behave import *
from selenium import webdriver
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support.ui import Select
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import TimeoutException

use_step_matcher("re")

@given("I am on Book my show website")
def step1(context):

    context.browser = webdriver.Chrome("C:\\Users\\javed\Downloads\\chromedriver.exe")
    context.browser.get("https://in.bookmyshow.com/")
    context.browser.implicitly_wait(30)
    context.browser.maximize_window()

@when(u'I click on Movies link')
def step3(context):
    lnkRegion= context.browser.find_element_by_xpath("//li[@class='region-list']")
    lnkRegion.click()
    btnCancel = context.browser.find_element_by_xpath("//button[@id='wzrk-cancel']")
    btnCancel.click()
    lnkSection = context.browser.find_element_by_xpath("//a[contains(text(),'Movies')]")
    assert lnkSection.is_displayed()
    lnkSection.click()

@when(u'I choose Thugs of Hindostan')
def step4(context):
     lblMovie = context.browser.find_element_by_xpath("//h4[contains(text(),'Thugs of Hindostan')]")
     lblMovie.click()

@when(u'I click on book tickets button')
def step5(context):
    btnBookTickets = context.browser.find_element_by_xpath("//a[@class='showtimes btn _cuatro']")
    btnBookTickets.click()

@when(u'I select 10:30 show of INOX: Inorbit Mall Malad')
def step6(context):
    lnkCinemaHall = context.browser.find_element_by_xpath("//strong[contains(text(),'Inorbit Mall')]//../ancestor::div[@class='listing-info']/../div[@class='body ']//div/a")
    lnkCinemaHall.click()

@when(u'I accept terms & conditions')
def step7(context):
    btnAlert = context.browser.find_element_by_xpath("//a[@id='btnPopupAccept']")
    btnAlert.click()
    """try:
        WebDriverWait(context.browser, 3).until(EC.alert_is_present(),
                                   'Timed out waiting for PA creation ' +
                                   'confirmation popup to appear.')

        context.browser.switch_to.alert.accept()
        print("alert accepted")
    except TimeoutException:
    """

@when(u'I choose \'2\' tickets')
def step8(context):
    context.browser.implicitly_wait(5)
    lnkTickets=context.browser.find_element_by_xpath("//li[@id='pop_2']")
    lnkTickets.click()
    btnSelectSeats = context.browser.find_element_by_xpath("//div[@id='proceed-Qty']")
    btnSelectSeats.click()


@when(u'I choose seat')
def step9(context):
    context.browser.implicitly_wait(5)
    lblSeat1=context.browser.find_element_by_xpath("//a[@class='_available']")
    lblSeat1.click()



@when(u'I click on Pay button')
def step10(context):
    btnPay=context.browser.find_element_by_xpath("//a[@id='btmcntbook']")
    btnPay.click()


@when(u'I select \'m-Ticket\'')
def step_impl(context):
    rbtnMticket =context.browser.find_element_by_xpath("//div[@id='shmticket']")
    rbtnMticket.click()


@when(u'I click on Proceed button')
def step_impl(context):
    btnProceed = context.browser.find_element_by_xpath("//a[@id='prePay']")
    btnProceed.click()


@when(u'I enter contact details')
def step_impl(context):


 """@when(u'I enter payment details')
def step_impl(context):



@when(u'I click on make payment button')
def step_impl(context):



@when(u'I complete payment on bank site')
def step_impl(context):



@then(u'I should get ticket details')
def step_impl(context):
"""